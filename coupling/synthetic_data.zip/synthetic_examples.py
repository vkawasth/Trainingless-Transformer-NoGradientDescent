"""synthetic_examples.py -- one seeded synthetic data set behind the worked examples of the three papers.

Scenario.  A content-moderation model sees items with a binary label Y in {safe, harmful} and takes an action
A in {accept, review, reject}.  The confusion table of (Y, A) is a coupling of the label marginal f and the action
marginal g: a point of the 2x3 coupling polytope Cpl(f, g).  The marginals f = (0.52, 0.48), g = (0.31, 0.35, 0.34)
lie in the hexagon chamber (the del Pezzo surface of degree 6), the first point of the Fukaya table.

Sections (each writes CSV files to data/ and numbers to results.json):
  S1 samples of (Y, A); the empirical confusion table as a point of the polytope; Frechet (partial identification)
     bounds on P(harmful, accept) from the marginals alone
  S2 chamber identification from samples: observed error rate against the Hoeffding union bound, far from and near a wall
  S3 independence tests: Pearson chi^2 = N * Fisher form at the product coupling, G = 2N * KL = 2N * mutual information;
     null calibration with df = dim Cpl = (n-1)(m-1) = 2, and power at the true table
  S4 two models on the same labels: two confusion tables = a 2-horn; the filler polytope bounds a joint metric
     (both models accept a harmful item); the gluing filler is conditional independence; the truth has correlated errors
  S5 horn data from separate studies: sampling noise breaks compatibility at rate 1/sqrt(N) (a primary obstruction),
     while the contextual fraction stays put (a secondary obstruction)
  S6 a deep ensemble as admissibility data on 3 classes: an overconfident claim (level one), a claim reachable by mixing
     members but not by any admissible ensemble posterior (extension-obstructed, with its secondary-obstruction interval)
  S7 a finite-sample hallucination test from the level-one certificate: size under the null and power, by N
  S8 label noise as stochastic change of base: obstructions shrink by at most the Dobrushin coefficient
"""
import csv, itertools, json, math, os
import numpy as np
from scipy.optimize import linprog
from scipy.stats import chi2 as chi2dist

HERE = os.path.dirname(os.path.abspath(__file__)); DATA = os.path.join(HERE, "data"); os.makedirs(DATA, exist_ok=True)
OUT = {}
def save_csv(name, header, rows):
    with open(os.path.join(DATA, name), "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(header); w.writerows(rows)
def lp(c, A_ub=None, b_ub=None, A_eq=None, b_eq=None, bounds=None):
    r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    assert r.status == 0, r.message
    return r
LAB = ["safe", "harmful"]; ACT = ["accept", "review", "reject"]
f = np.array([0.52, 0.48]); g = np.array([0.31, 0.35, 0.34])
ALPHA = np.array([[0.28, 0.20, 0.04], [0.03, 0.15, 0.30]])          # true confusion table
assert np.allclose(ALPHA.sum(1), f) and np.allclose(ALPHA.sum(0), g)
def walls(n, m):
    out = []
    for r in range(1, n):
        for I in itertools.combinations(range(n), r):
            if 0 not in I: continue
            for s in range(1, m):
                for J in itertools.combinations(range(m), s): out.append((I, J))
    return out
W23 = walls(2, 3)
def wall_values(f, g): return np.array([f[list(I)].sum() - g[list(J)].sum() for I, J in W23])
def cell_bounds(f, g, cell):
    """min and max of one cell over Cpl(f, g)"""
    n, m = len(f), len(g); A = [[1.0 * (k // m == i) for k in range(n * m)] for i in range(n)] + \
                                [[1.0 * (k % m == j) for k in range(n * m)] for j in range(m)]
    b = np.r_[f, g]; c = np.zeros(n * m); c[cell[0] * m + cell[1]] = 1
    lo = lp(c, A_eq=A, b_eq=b, bounds=[(0, None)] * (n * m)).fun
    hi = -lp(-c, A_eq=A, b_eq=b, bounds=[(0, None)] * (n * m)).fun
    return lo, hi

# ===================================================================== S1
rng = np.random.default_rng(20261006)
N1 = 2000
cells = [(i, j) for i in range(2) for j in range(3)]
idx = rng.choice(6, size=N1, p=ALPHA.ravel())
save_csv("triage_samples.csv", ["item", "label", "action"], [(k, LAB[cells[c][0]], ACT[cells[c][1]]) for k, c in enumerate(idx)])
cnt = np.bincount(idx, minlength=6).reshape(2, 3); ahat = cnt / N1
fhat, ghat = ahat.sum(1), ahat.sum(0)
lo, hi = cell_bounds(f, g, (1, 0))
OUT["S1"] = dict(N=N1, counts=cnt.tolist(), alpha_hat=ahat.round(4).tolist(), f_hat=fhat.round(4).tolist(),
                 g_hat=ghat.round(4).tolist(), true_alpha=ALPHA.tolist(),
                 frechet_harmful_accept=[round(lo, 4), round(hi, 4)], true_harmful_accept=ALPHA[1, 0],
                 wall_values_true=wall_values(f, g).round(4).tolist(), delta_true=float(np.abs(wall_values(f, g)).min()))

# ===================================================================== S2
def chamber_sim(f, g, alpha, Ns, R, seed):
    rr = np.random.default_rng(seed); s0 = np.sign(wall_values(f, g)); dl = np.abs(wall_values(f, g)).min(); rows = []
    for N in Ns:
        err = 0
        for _ in range(R):
            c = rr.multinomial(N, alpha.ravel()).reshape(alpha.shape) / N
            err += np.any(np.sign(wall_values(c.sum(1), c.sum(0))) != s0)
        bound = min(1.0, 2 * len(W23) * math.exp(-N * dl ** 2 / 2))
        rows.append((N, err / R, bound))
    return dl, rows
dl_far, far = chamber_sim(f, g, ALPHA, [50, 100, 200, 500, 1000], 4000, 1)
gn = np.array([0.31, 0.19, 0.50]); alpha_near = np.outer(f, gn)
dl_near, near = chamber_sim(f, gn, alpha_near, [100, 1000, 5000, 20000, 50000], 2000, 2)
save_csv("chamber_identification.csv", ["case", "delta", "N", "observed_error", "hoeffding_bound"],
         [("far", dl_far, *r) for r in far] + [("near", dl_near, *r) for r in near])
need = lambda dl, eta: 2 * math.log(2 * len(W23) / eta) / dl ** 2
OUT["S2"] = dict(delta_far=dl_far, delta_near=dl_near, far=far, near=near,
                 N_needed_far=math.ceil(need(dl_far, 0.05)), N_needed_near=math.ceil(need(dl_near, 0.05)))

# ===================================================================== S3
def stats(c):
    N = c.sum(); a = c / N; p = np.outer(a.sum(1), a.sum(0))
    v = a - p; fisher = float((v ** 2 / p).sum())
    kl = float(sum(x * math.log(x / y) for x, y in zip(a.ravel(), p.ravel()) if x > 0))
    return N * fisher, 2 * N * kl, fisher, kl
X2, G2, fis, kl = stats(cnt)
pear = float(((cnt - np.outer(cnt.sum(1), cnt.sum(0)) / N1) ** 2 / (np.outer(cnt.sum(1), cnt.sum(0)) / N1)).sum())
crit = chi2dist.ppf(0.95, 2)
def calib(alpha, N, R, seed):
    rr = np.random.default_rng(seed); rej = [0, 0]
    for _ in range(R):
        c = rr.multinomial(N, alpha.ravel()).reshape(alpha.shape)
        if (c.sum(0) == 0).any() or (c.sum(1) == 0).any(): continue
        x, gg, _, _ = stats(c); rej[0] += x > crit; rej[1] += gg > crit
    return rej[0] / R, rej[1] / R
null = calib(np.outer(f, g), 500, 4000, 3); power = calib(ALPHA, 50, 4000, 4)
save_csv("independence_tests.csv", ["setting", "N", "reps", "pearson_rejection", "G_rejection"],
         [("null: product coupling", 500, 4000, *null), ("alternative: true table", 50, 4000, *power)])
OUT["S3"] = dict(pearson=X2, pearson_textbook=pear, G=G2, fisher_form=fis, KL=kl, MI_nats=kl, df=2, crit=crit,
                 p_pearson=float(chi2dist.sf(X2, 2)), null_rejection=null, power_N50=power)

# ===================================================================== S4  two models, one label set
BETA = np.array([[0.25, 0.22, 0.05], [0.05, 0.13, 0.30]])           # model B's confusion table
assert np.allclose(BETA.sum(1), f)
def max_agree(pa, pb):
    """coupling of two action laws maximizing agreement (LP)"""
    m = 3; A = [[1.0 * (k // m == i) for k in range(9)] for i in range(3)] + [[1.0 * (k % m == j) for k in range(9)] for j in range(3)]
    c = -np.array([1.0 * (k // m == k % m) for k in range(9)])
    return lp(c, A_eq=A, b_eq=np.r_[pa, pb], bounds=[(0, None)] * 9).x.reshape(3, 3)
CORR = 0.6
P = np.zeros((2, 3, 3))
for y in range(2):
    pa, pb = ALPHA[y] / f[y], BETA[y] / f[y]
    P[y] = f[y] * ((1 - CORR) * np.outer(pa, pb) + CORR * max_agree(pa, pb))
assert np.allclose(P.sum(2), ALPHA) and np.allclose(P.sum(1), BETA)
N4 = 5000; rng4 = np.random.default_rng(5)
trip = list(itertools.product(range(2), range(3), range(3)))
s4 = rng4.choice(len(trip), size=N4, p=P.ravel())
save_csv("two_models_samples.csv", ["item", "label", "model_A", "model_B"],
         [(k, LAB[trip[t][0]], ACT[trip[t][1]], ACT[trip[t][2]]) for k, t in enumerate(s4)])
Pe = np.bincount(s4, minlength=18).reshape(2, 3, 3) / N4
def filler_bounds(fa, fb, target):
    """min/max of target cell over laws on 2x3x3 with the two face tables fa (Y,A) and fb (Y,B)"""
    A = []; b = []
    for y in range(2):
        for a in range(3):
            A.append([1.0 * (t[0] == y and t[1] == a) for t in trip]); b.append(fa[y, a])
        for bb in range(3):
            A.append([1.0 * (t[0] == y and t[2] == bb) for t in trip]); b.append(fb[y, bb])
    c = np.array([1.0 * (t == target) for t in trip])
    return lp(c, A_eq=A, b_eq=b, bounds=[(0, None)] * 18).fun, -lp(-c, A_eq=A, b_eq=b, bounds=[(0, None)] * 18).fun
def glue(fa, fb):
    fy = fa.sum(1); return np.array([[[fa[y, a] * fb[y, b] / fy[y] for b in range(3)] for a in range(3)] for y in range(2)])
T = (1, 0, 0)                                                         # harmful, A accepts, B accepts
pop = dict(bounds=filler_bounds(ALPHA, BETA, T), glue=glue(ALPHA, BETA)[T], truth=P[T])
fa_e, fb_e = Pe.sum(2), Pe.sum(1)
emp = dict(bounds=filler_bounds(fa_e, fb_e, T), glue=glue(fa_e, fb_e)[T], truth=Pe[T])
# conditional covariance of the two "accept" indicators given harmful, and both-wrong probabilities
def ccov(Q, y):
    q = Q[y] / Q[y].sum(); return q[0, 0] - q[0].sum() * q[:, 0].sum()
OUT["S4"] = dict(BETA=BETA.tolist(), corr=CORR, N=N4, target="P(harmful, A=accept, B=accept)",
                 population={k: (np.round(v, 5).tolist() if hasattr(v, "__len__") else round(float(v), 5)) for k, v in pop.items()},
                 empirical={k: (np.round(v, 5).tolist() if hasattr(v, "__len__") else round(float(v), 5)) for k, v in emp.items()},
                 cond_cov_true=round(float(ccov(P, 1)), 5), cond_cov_emp=round(float(ccov(Pe, 1)), 5),
                 cond_cov_glue=round(float(ccov(glue(ALPHA, BETA), 1)), 12))

# ===================================================================== S5  horn data from separate studies
n = 3; k = 0; faces = [i for i in range(n + 1) if i != k]; fidx = {i: tuple(j for j in range(n + 1) if j != i) for i in faces}
assign = list(itertools.product((0, 1), repeat=n))
def parity_face(odd):
    return np.array([(1 / 2 ** (n - 1)) if sum(a) % 2 == odd else 0.0 for a in assign])
rngG = np.random.default_rng(6); Gglob = rngG.dirichlet(np.ones(16)); glob = list(itertools.product((0, 1), repeat=n + 1))
def restrict(G, i):
    v = np.zeros(len(assign))
    for s, p in zip(glob, G): v[assign.index(tuple(s[j] for j in fidx[i]))] += p
    return v
TMIX = 0.6
pop_faces = {i: TMIX * parity_face(int(i == faces[0])) + (1 - TMIX) * restrict(Gglob, i) for i in faces}
def encode(faces_d):
    return np.concatenate([faces_d[i] for i in faces]) / len(faces)
SRC = np.array([np.concatenate([np.eye(len(assign))[assign.index(tuple(s[j] for j in fidx[i]))] for i in faces]) / len(faces) for s in glob])
def cf(x):
    r = lp(-np.ones(len(SRC)), A_ub=SRC.T, b_ub=x, bounds=[(0, None)] * len(SRC)); return 1 + r.fun
def incompat(fd):
    worst = 0
    for i, j in itertools.combinations(faces, 2):
        common = sorted(set(fidx[i]) & set(fidx[j]))
        def marg(ff, fi):
            out = {}
            for a, p in zip(assign, ff):
                key = tuple(a[fidx[fi].index(c)] for c in common); out[key] = out.get(key, 0) + p
            return out
        mi, mj = marg(fd[i], i), marg(fd[j], j)
        worst = max(worst, 0.5 * sum(abs(mi[kk] - mj[kk]) for kk in mi))
    return worst
cf_pop = cf(encode(pop_faces)); rows5 = []
rng5 = np.random.default_rng(7)
for N in (100, 1000, 10000, 100000):
    vals = []
    for _ in range(50):
        fd = {i: rng5.multinomial(N, pop_faces[i]) / N for i in faces}
        vals.append((incompat(fd), cf(encode(fd))))
    v = np.array(vals); rows5.append((N, float(v[:, 0].mean()), float(v[:, 1].mean()), float(v[:, 1].std())))
save_csv("horn_studies.csv", ["N_per_study", "mean_max_overlap_TV", "mean_CF", "sd_CF"], rows5)
OUT["S5"] = dict(t=TMIX, n=n, CF_population=cf_pop, CF_parity=0.5, incompat_population=incompat(pop_faces), rows=rows5)

# ===================================================================== S6  a deep ensemble as admissibility data
rng6 = np.random.default_rng(8)
K = 5; MEM = rng6.dirichlet([2.0, 2.0, 2.0], size=K)                 # members' predictive laws on 3 classes (S1)
w_unif = np.ones(K) / K
w_post = np.array([0.40, 0.30, 0.15, 0.10, 0.05])                     # ensemble posterior after validation data
S2 = np.array([w_unif, w_post])                                        # admissible second-order states
def d_conv(x, P):
    m, d = P.shape
    A = np.block([[P.T, -np.eye(d)], [-P.T, -np.eye(d)]]); b = np.r_[x, -x]
    r = lp(np.r_[np.zeros(m), np.ones(d)], A_ub=A, b_ub=b, A_eq=np.r_[np.ones(m), np.zeros(d)][None, :], b_eq=[1],
           bounds=[(0, None)] * (m + d))
    return r.fun, r.x[:m]
def certificate(x, P):
    """optimal level-one certificate: maximize <f,x> - max_rho <f,rho> over ||f||_inf <= 1"""
    d = len(x); m = len(P)                                          # variables f (d), s (1): max <f,x> - s, <f,rho> <= s
    c = np.r_[-x, 1.0]; A = np.c_[P, -np.ones(m)]
    r = lp(c, A_ub=A, b_ub=np.zeros(m), bounds=[(-1, 1)] * d + [(None, None)])
    return -r.fun, r.x[:d]
def mu_min(x, P):
    r = lp(-np.ones(len(P)), A_ub=P.T, b_ub=x, bounds=[(0, None)] * len(P)); return 1 + r.fun
claims = {"ensemble mean": w_unif @ MEM, "overconfident": np.array([0.96, 0.03, 0.01])}
E1 = S2 @ MEM                                                          # the two admissible ensemble predictions
lam = 0.5; claims["member mix off E1"] = None
# a point of conv(members) far from the segment E1: the member mixture with weights (0,0,0,0.5,0.5)
claims["member mix off E1"] = 0.35 * MEM[0] + 0.15 * MEM[2] + 0.5 * MEM[4]          # interior of conv(members), off E1
claims["mildly overconfident"] = None
def o3_interval(x):
    """secondary obstruction I(x) = o3(fibre): o3^- by LP, o3^+ by maximizing over fibre vertices"""
    m = K; q = len(S2)
    # o3^-: min ||Pi - sum_j w_j S2_j||_1, Pi >= 0, Pi^T MEM = x, sum Pi = 1
    nv = m + q + m
    A_ub = np.block([[np.eye(m), -S2.T, -np.eye(m)], [-np.eye(m), S2.T, -np.eye(m)]])
    A_eq = np.vstack([np.c_[MEM.T, np.zeros((3, q + m))], np.r_[np.ones(m), np.zeros(q + m)], np.r_[np.zeros(m), np.ones(q), np.zeros(m)]])
    lo = lp(np.r_[np.zeros(m + q), np.ones(m)], A_ub=A_ub, b_ub=np.zeros(2 * m), A_eq=A_eq, b_eq=np.r_[x, 1, 1],
            bounds=[(0, None)] * nv).fun
    # o3^+: vertices of the fibre {Pi >= 0, MEM^T Pi = x, 1^T Pi = 1}: basic solutions with 3 nonzeros
    hi = 0; Aeq = np.vstack([MEM.T, np.ones(m)])[:3]                   # rows of MEM sum to 1, so 3 equations suffice
    for S in itertools.combinations(range(m), 3):
        M = Aeq[:, S]
        if abs(np.linalg.det(M)) < 1e-12: continue
        sol = np.linalg.solve(M, x)
        if (sol < -1e-12).any(): continue
        Pi = np.zeros(m); Pi[list(S)] = sol
        dist = lp(np.r_[np.zeros(q), np.ones(m)], A_ub=np.block([[-S2.T, -np.eye(m)], [S2.T, -np.eye(m)]]),
                  b_ub=np.r_[-Pi, Pi], A_eq=[np.r_[np.ones(q), np.zeros(m)]], b_eq=[1], bounds=[(0, None)] * (q + m)).fun
        hi = max(hi, dist)
    return lo, hi
_, wts0 = d_conv(claims["overconfident"], MEM); xb = wts0 @ MEM
claims["mildly overconfident"] = xb + 0.12 * (claims["overconfident"] - xb)
rows6 = []; OUT["S6"] = dict(members=MEM.round(4).tolist(), w_post=w_post.tolist(), E1=E1.round(4).tolist(), claims={})
for name, x in claims.items():
    dL, _ = d_conv(x, MEM); dE, _ = d_conv(x, E1); val, fcert = certificate(x, MEM); mu = mu_min(x, MEM)
    lo3, hi3 = o3_interval(x) if dL < 1e-9 else (float("nan"), float("nan"))
    kind = "local at level one" if dL > 1e-9 else ("extension-obstructed" if dE > 1e-9 else "liftable")
    OUT["S6"]["claims"][name] = dict(x=np.round(x, 4).tolist(), d_L1=round(dL, 4), d_E1=round(dE, 4), certificate=np.round(fcert, 3).tolist(),
                                     margin=round(val, 4), mu_min=round(mu, 4), o3_interval=[round(lo3, 4), round(hi3, 4)], type=kind)
    rows6.append((name, *np.round(x, 4), round(dL, 4), round(dE, 4), round(mu, 4), round(lo3, 4), round(hi3, 4), kind))
save_csv("ensemble_members.csv", ["member", "p_class0", "p_class1", "p_class2", "weight_uniform", "weight_posterior"],
         [(k, *MEM[k].round(6), w_unif[k], w_post[k]) for k in range(K)])
save_csv("ensemble_claims.csv", ["claim", "x0", "x1", "x2", "d_L1", "d_E1", "unmodeled_weight", "o3_minus", "o3_plus", "type"], rows6)

# ===================================================================== S7  finite-sample hallucination test
xover = claims["overconfident"]; dL_over, wts = d_conv(xover, MEM)
xnull = wts @ MEM                                                        # nearest admissible point: boundary null
xmild = claims["mildly overconfident"]; dL_mild, _ = d_conv(xmild, MEM)
def test(xtrue, N, R, seed, eta=0.05):
    rr = np.random.default_rng(seed); rej = 0
    for _ in range(R):
        s = rr.multinomial(N, xtrue)
        half = rr.binomial(s, 0.5)                                      # split the sample: learn f, then test
        x1, x2 = half / max(half.sum(), 1), (s - half) / max((s - half).sum(), 1)
        _, fcert = certificate(x1, MEM)
        stat = fcert @ x2 - max(MEM @ fcert); n2 = (s - half).sum()
        rej += stat > math.sqrt(2 * math.log(1 / eta) / n2)
    return rej / R
rows7 = []
for N in (100, 200, 400, 800, 1600, 3200):
    rows7.append((N, test(xnull, N, 1000, 9), test(xmild, N, 1000, 10), test(xover, N, 1000, 11)))
save_csv("hallucination_test.csv", ["N", "rejection_null_boundary", "rejection_mild", "rejection_overconfident"], rows7)
OUT["S7"] = dict(eta=0.05, rows=rows7, d_L1_overconfident=dL_over, d_L1_mild=dL_mild, x_null=xnull.round(4).tolist())

# ===================================================================== S8  label noise as change of base
def sym_noise(eps): return (1 - eps) * np.eye(3) + eps / 2 * (1 - np.eye(3))
def dobrushin(Kr): return max(0.5 * np.abs(Kr[a] - Kr[b]).sum() for a in range(3) for b in range(3))
rows8 = []
for eps in (0.0, 0.1, 0.2, 0.4, 0.6, 2 / 3):
    Kr = sym_noise(eps); xo = xover @ Kr; Mo = MEM @ Kr
    dn, _ = d_conv(xo, Mo); eta = dobrushin(Kr)
    rows8.append((round(eps, 4), round(eta, 4), round(dn, 4), round(eta * dL_over, 4)))
    assert dn <= eta * dL_over + 1e-9
# an asymmetric channel: harmful labels flipped toward class 1 only (class 0 -> 1 with rate eps)
for eps in (0.2, 0.5):
    Kr = np.eye(3); Kr[0] = [1 - eps, eps, 0]; xo = xover @ Kr; Mo = MEM @ Kr
    dn, _ = d_conv(xo, Mo); eta = dobrushin(Kr)
    rows8.append((f"asym {eps}", round(eta, 4), round(dn, 4), round(eta * dL_over, 4)))
    assert dn <= eta * dL_over + 1e-9
save_csv("label_noise.csv", ["noise", "dobrushin", "d_L1_after_noise", "bound"], rows8)
OUT["S8"] = dict(rows=rows8, d_L1_before=dL_over)

with open(os.path.join(HERE, "results.json"), "w") as fh: json.dump(OUT, fh, indent=1, default=float)
for k, v in OUT.items(): print(k, json.dumps(v, default=float)[:900])

# ===================================================================== checks
res = []
def check(name, c, info=""):
    res.append(bool(c)); print(("PASS " if c else "FAIL ") + name + (f"   [{info}]" if info else ""))
check("Y1 the true table and its marginals lie in the hexagon chamber; Frechet bounds contain the true cell",
      np.all(np.sign(wall_values(f, g)) == np.sign(wall_values(np.array([.5, .5]), np.array([1/3, 1/3, 1/3]))))
      and lo <= ALPHA[1, 0] <= hi)
check("Y2 observed chamber-error rates never exceed the Hoeffding union bound",
      all(r[1] <= r[2] + 1e-12 for r in far + near))
check("Y3 Pearson chi^2 = N * Fisher form at the empirical product coupling; G = 2N * KL; null rejection near 0.05 with df 2",
      abs(X2 - pear) < 1e-8 and abs(G2 - 2 * N1 * kl) < 1e-8 and 0.035 < null[0] < 0.065 and 0.035 < null[1] < 0.065,
      f"null rejection {null}")
check("Y4 two models: the true joint metric lies in the filler-polytope bounds and differs from the gluing value; "
      "gluing has zero conditional covariance", pop["bounds"][0] - 1e-9 <= pop["truth"] <= pop["bounds"][1] + 1e-9
      and abs(pop["truth"] - pop["glue"]) > 1e-3 and abs(OUT["S4"]["cond_cov_glue"]) < 1e-12)
ratios = [rows5[i][1] / rows5[i + 1][1] for i in range(3)]
check("Y5 study-level incompatibility shrinks like 1/sqrt(N) (ratio per decade near sqrt(10)); the empirical CF approaches the "
      "population CF", all(2.5 < r < 4.0 for r in ratios) and abs(rows5[-1][2] - cf_pop) < 3 * rows5[-1][3] + 1e-3,
      f"ratios {np.round(ratios, 2).tolist()}, CF {cf_pop:.4f} vs {rows5[-1][2]:.4f}")
cl = OUT["S6"]["claims"]
check("Y6 ensemble claims: types as stated; d(x, E1) <= o3^- for the extension-obstructed claim",
      cl["overconfident"]["type"] == "local at level one" and cl["member mix off E1"]["type"] == "extension-obstructed"
      and cl["member mix off E1"]["d_E1"] <= cl["member mix off E1"]["o3_interval"][0] + 1e-9 and cl["ensemble mean"]["type"] == "liftable")
check("Y7 the split-sample certificate test has size <= 0.05 at the boundary null and power rising with N",
      all(r[1] <= 0.05 for r in rows7) and all(rows7[i][2] <= rows7[i + 1][2] + 0.02 for i in range(len(rows7) - 1)))
check("Y8 label noise: d after noise <= Dobrushin coefficient * d before, with equality for symmetric noise",
      all(r[2] <= r[3] + 1e-9 for r in rows8) and all(abs(r[2] - r[3]) < 1e-3 for r in rows8 if not str(r[0]).startswith("asym")))
print(f"\n{sum(res)}/{len(res)} checks passed")
