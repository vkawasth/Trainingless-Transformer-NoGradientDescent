"""audit_crossrefs.py -- check every numbered cross-paper citation against the target paper's .aux/.toc."""
import re, sys
P = "/home/claude/paper/"
papers = {"theory": "conditionals_couplings", "companion": "coupling_polytopes_companion", "tower": "three_level_tower_v10"}
keys = {"theory": {"Awasthi-Tower": "tower", "Awasthi-Family": "companion"},
        "companion": {"Conditionals": "theory", "Tower": "tower"},
        "tower": {"Conditionals": "theory", "Awasthi-Family": "companion"}}
def labels(name):
    aux = open(P + papers[name] + ".aux").read(); out = {}
    for lab, num in re.findall(r"\\newlabel\{([^}]*)\}\{\{([^}]*)\}", aux): out.setdefault(num, set()).add(lab.split(":")[0])
    toc = open(P + papers[name] + ".toc").read()
    for num in re.findall(r"\\numberline \{([^}]*)\}", toc): out.setdefault(num, set()).add("sec")
    return out
L = {k: labels(k) for k in papers}
KIND = {"Thm": {"thm"}, "Prop": {"prop"}, "Def": {"def"}, "Cor": {"cor"}, "Obs": {"obs"}, "Question": {"q", "conj"},
        "Conj": {"conj"}, "Lemma": {"lem"}, "Ex": {"ex"}, "Remark": {"rem"}, "Section": {"sec", "app", "subsec"}, "S": {"sec", "app"},
        "App": {"sec", "app"}}
bad = 0; total = 0
for src, km in keys.items():
    tex = open(P + papers[src] + ".tex").read()
    for opt, key in re.findall(r"\\cite\[([^\]]*)\]\{([^}]*)\}", tex):
        if key not in km: continue
        tgt = km[key]
        for item in re.split(r",\s*", opt):
            item = item.replace("~", " ").replace("\\S\\S", "S ").replace("\\S", "S ").strip()
            m = re.match(r"(Thm|Prop|Def|Cor|Obs|Question|Conj|Lemma|Ex|Remark|Section|Sections|App|S)\.?\s*([0-9A-Z][0-9.]*)(?:--([0-9]+))?(\([ivx]+\))?", item)
            if not m:
                if re.match(r"^S?\s*[0-9]", item):
                    m = re.match(r"()S?\s*([0-9][0-9.]*)()()", item)
                else:
                    print(f"  ? unparsed in {src}: [{opt}]{{{key}}}"); continue
            kind, num = m.group(1).rstrip("s") or "S", m.group(2).rstrip(".")
            if kind == "Section": kind = "Section"
            nums = [num] + ([m.group(3)] if m.group(3) else [])
            for nm in nums:
                total += 1; kinds = L[tgt].get(nm, set()); want = KIND.get(kind, set())
                ok = bool(kinds & want) if want else bool(kinds)
                if not ok:
                    bad += 1; print(f"  MISMATCH {src} -> {tgt}: [{opt}] item '{item}' -> number {nm} has {sorted(kinds) or 'nothing'}")
print(f"{total} numbered cross-paper references checked, {bad} mismatches")
